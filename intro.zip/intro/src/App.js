import React, { useState } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import { Container, Row, Col,Button } from "reactstrap";
import  Cel from "./components/Cel";
import Kelvin from "./components/Kelvin";
import Fahren from "./components/Fahren";

function App() {
  const [cel, setCel] = useState(0);
  const [data,setData] = useState({
    cel:0,
    fahren : 0,
    kelvin : 0
  })

  const celUpdate = ()=>{
    var celler = cel+1;
    setCel(celler);
    setData({
      cel:celler,
      fahren:celler+32,
      kelvin:celler+273
    })

  }

  return (
    <div className="App">
      <Container>
        <h2>Hava Nasıl</h2>
        <h4>Şu an sıcaklık {cel} derece</h4>
        <Button color="primary" onClick={celUpdate}>Sıcaklık Arttır</Button>
        <h4 style={{marginTop:"10px"}}>3 Birimde Sıcaklık Ölçümü</h4>
        <Row>
          <Col>
            <Cel data = {data}></Cel>
          </Col>
          <Col>
            <Kelvin data = {data}></Kelvin>
          </Col>
          <Col>
            <Fahren data = {data}></Fahren>
          </Col>
         
        </Row>
      </Container>
    </div>
  );
}

export default App;
