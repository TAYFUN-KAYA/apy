import React from 'react'

export default function Cel({data}) {
  return (
    <div>Celcius : {data.cel}</div>
  )
}
