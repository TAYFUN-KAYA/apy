import React from 'react'

export default function Fahren({data}) {
  return (
    <div>Fahrenheit :{data.fahren}</div>
  )
}
