import React from 'react'

export default function Kelvin({data}) {
  return (
    <div>Kelvin :{data.kelvin}</div>
  )
}
